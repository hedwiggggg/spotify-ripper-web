#ifndef VERSION_H
#define VERSION_H
const char *fdkaac_version = "0.6.2";
#endif
